import { useState, useEffect } from 'react';
import { 
  Activity, 
  Heart, 
  Loader2, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  FileText, 
  CreditCard,
  ChevronRight,
  X,
  Bell,
  Sparkles,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  Users,
  Stethoscope,
  Pill,
  Droplets,
  Thermometer,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';

// ============================================
// LOADING COMPONENTS
// ============================================

const PulseRingLoader = () => (
  <div className="relative flex items-center justify-center">
    <div className="absolute w-20 h-20 rounded-full border-4 border-primary/30 animate-pulse-ring" />
    <div className="absolute w-14 h-14 rounded-full border-4 border-primary/50 animate-pulse-ring animation-delay-200" />
    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
      <Heart className="w-5 h-5 text-white animate-heartbeat" />
    </div>
  </div>
);

const EKGLoader = () => (
  <div className="flex items-center justify-center">
    <svg width="200" height="60" viewBox="0 0 200 60" className="overflow-visible">
      <path
        d="M0 30 L20 30 L25 10 L30 50 L35 30 L40 30 L45 30 L50 5 L55 55 L60 30 L80 30 L85 15 L90 45 L95 30 L115 30 L120 10 L125 50 L130 30 L150 30 L155 20 L160 40 L165 30 L200 30"
        fill="none"
        stroke="hsl(var(--primary))"
        strokeWidth="2"
        className="animate-ekg"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </div>
);

const DNALoader = () => (
  <div className="flex items-center justify-center gap-1">
    {[...Array(8)].map((_, i) => (
      <div
        key={i}
        className="w-2 h-12 rounded-full bg-gradient-to-b from-primary to-accent animate-dna"
        style={{ animationDelay: `${i * 0.1}s` }}
      />
    ))}
  </div>
);

const SkeletonCard = () => (
  <div className="p-6 rounded-xl border bg-card space-y-4">
    <div className="flex items-center gap-4">
      <Skeleton className="w-12 h-12 rounded-full skeleton-shimmer" />
      <div className="space-y-2 flex-1">
        <Skeleton className="h-4 w-3/4 skeleton-shimmer" />
        <Skeleton className="h-3 w-1/2 skeleton-shimmer" />
      </div>
    </div>
    <Skeleton className="h-20 w-full rounded-lg skeleton-shimmer" />
    <div className="flex gap-2">
      <Skeleton className="h-8 w-20 rounded-md skeleton-shimmer" />
      <Skeleton className="h-8 w-20 rounded-md skeleton-shimmer" />
    </div>
  </div>
);

// ============================================
// TOAST NOTIFICATION
// ============================================

interface Toast {
  id: number;
  title: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

const ToastItem = ({ toast, onRemove }: { toast: Toast; onRemove: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onRemove, 4000);
    return () => clearTimeout(timer);
  }, [onRemove]);

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-emerald-500" />,
    error: <AlertCircle className="w-5 h-5 text-red-500" />,
    warning: <AlertCircle className="w-5 h-5 text-amber-500" />,
    info: <Activity className="w-5 h-5 text-blue-500" />
  };

  const gradients = {
    success: 'from-emerald-500/20 to-emerald-500/5',
    error: 'from-red-500/20 to-red-500/5',
    warning: 'from-amber-500/20 to-amber-500/5',
    info: 'from-blue-500/20 to-blue-500/5'
  };

  return (
    <div className={`animate-toast-in flex items-start gap-3 p-4 rounded-xl border bg-gradient-to-r ${gradients[toast.type]} backdrop-blur-sm shadow-lg min-w-[320px]`}>
      {icons[toast.type]}
      <div className="flex-1">
        <p className="font-semibold text-sm">{toast.title}</p>
        <p className="text-xs text-muted-foreground">{toast.message}</p>
      </div>
      <button onClick={onRemove} className="text-muted-foreground hover:text-foreground">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};

// ============================================
// COLOR SCHEME SHOWCASE
// ============================================

const ColorPalette = () => {
  const colors = [
    { name: 'Medical Blue', hsl: '199 89% 48%', hex: '#0ea5e9', usage: 'Primary actions, links' },
    { name: 'Healing Teal', hsl: '174 72% 56%', hex: '#2dd4bf', usage: 'Success states, accents' },
    { name: 'Care Green', hsl: '142 76% 36%', hex: '#16a34a', usage: 'Positive vitals, success' },
    { name: 'Alert Amber', hsl: '38 92% 50%', hex: '#f59e0b', usage: 'Warnings, pending' },
    { name: 'Urgent Red', hsl: '0 84% 60%', hex: '#ef4444', usage: 'Critical alerts, errors' },
    { name: 'Calm Purple', hsl: '262 56% 58%', hex: '#8b5cf6', usage: 'Specialty care, premium' },
    { name: 'Warm Coral', hsl: '14 100% 67%', hex: '#fb7185', usage: 'Maternity, pediatrics' },
    { name: 'Soft Lavender', hsl: '250 95% 76%', hex: '#a78bfa', usage: 'Mental health, wellness' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {colors.map((color, i) => (
        <div 
          key={i} 
          className="group p-4 rounded-xl border bg-card hover-lift cursor-pointer"
        >
          <div 
            className="w-full h-20 rounded-lg mb-3 shadow-inner transition-transform group-hover:scale-105"
            style={{ backgroundColor: color.hex }}
          />
          <p className="font-semibold text-sm">{color.name}</p>
          <p className="text-xs text-muted-foreground">{color.hex}</p>
          <p className="text-xs text-muted-foreground mt-1">{color.usage}</p>
        </div>
      ))}
    </div>
  );
};

// ============================================
// PATIENT CARD COMPONENT
// ============================================

const PatientCard = ({ patient, index }: { patient: any; index: number }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="p-5 rounded-xl border bg-card hover-lift gradient-border-card cursor-pointer animate-fade-in-up"
      style={{ animationDelay: `${index * 0.1}s` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
              {patient.initials}
            </div>
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
              patient.status === 'stable' ? 'bg-emerald-500' :
              patient.status === 'critical' ? 'bg-red-500 animate-pulse' :
              'bg-amber-500'
            }`} />
          </div>
          <div>
            <p className="font-semibold">{patient.name}</p>
            <p className="text-xs text-muted-foreground">{patient.id} • {patient.age}y</p>
          </div>
        </div>
        <Badge variant={patient.status === 'stable' ? 'default' : patient.status === 'critical' ? 'destructive' : 'secondary'}>
          {patient.status}
        </Badge>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="p-2 rounded-lg bg-muted/50 text-center">
          <Heart className="w-4 h-4 mx-auto mb-1 text-rose-500" />
          <p className="text-xs font-medium">{patient.vitals.hr}</p>
          <p className="text-[10px] text-muted-foreground">BPM</p>
        </div>
        <div className="p-2 rounded-lg bg-muted/50 text-center">
          <Activity className="w-4 h-4 mx-auto mb-1 text-primary" />
          <p className="text-xs font-medium">{patient.vitals.bp}</p>
          <p className="text-[10px] text-muted-foreground">BP</p>
        </div>
        <div className="p-2 rounded-lg bg-muted/50 text-center">
          <Thermometer className="w-4 h-4 mx-auto mb-1 text-amber-500" />
          <p className="text-xs font-medium">{patient.vitals.temp}</p>
          <p className="text-[10px] text-muted-foreground">°C</p>
        </div>
      </div>

      <div className={`flex items-center justify-between transition-all duration-300 ${isHovered ? 'opacity-100' : 'opacity-70'}`}>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">{patient.lastVisit}</span>
        </div>
        <ChevronRight className={`w-5 h-5 text-primary transition-transform duration-300 ${isHovered ? 'translate-x-1' : ''}`} />
      </div>
    </div>
  );
};

// ============================================
// MAIN APP
// ============================================

function App() {
  const [activeTab, setActiveTab] = useState('loading');
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [pageTransition, setPageTransition] = useState(false);

  // Simulate initial loading
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setIsLoading(false), 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const addToast = (type: Toast['type'], title: string, message: string) => {
    const newToast: Toast = {
      id: Date.now(),
      type,
      title,
      message
    };
    setToasts(prev => [...prev, newToast]);
  };

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleTabChange = (tab: string) => {
    setPageTransition(true);
    setTimeout(() => {
      setActiveTab(tab);
      setPageTransition(false);
    }, 300);
  };

  const patients = [
    { name: 'Sarah Johnson', initials: 'SJ', id: 'PT-001', age: 45, status: 'stable', vitals: { hr: 72, bp: '120/80', temp: 36.6 }, lastVisit: '2 hours ago' },
    { name: 'Michael Chen', initials: 'MC', id: 'PT-002', age: 62, status: 'critical', vitals: { hr: 98, bp: '140/95', temp: 38.2 }, lastVisit: '15 mins ago' },
    { name: 'Emily Davis', initials: 'ED', id: 'PT-003', age: 28, status: 'stable', vitals: { hr: 68, bp: '110/70', temp: 36.4 }, lastVisit: '1 day ago' },
    { name: 'Robert Wilson', initials: 'RW', id: 'PT-004', age: 55, status: 'watch', vitals: { hr: 85, bp: '130/85', temp: 37.1 }, lastVisit: '3 hours ago' },
  ];

  const tabs = [
    { id: 'loading', label: 'Loading States', icon: Loader2 },
    { id: 'colors', label: 'Color Schemes', icon: Sparkles },
    { id: 'transitions', label: 'Page Transitions', icon: Zap },
    { id: 'components', label: 'UI Components', icon: Layout },
    { id: 'effects', label: 'Hover Effects', icon: TrendingUp },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <PulseRingLoader />
        <div className="mt-8 w-64">
          <Progress value={progress} className="h-2" />
          <p className="text-center text-sm text-muted-foreground mt-3">
            Loading system... {progress}%
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <ToastItem key={toast.id} toast={toast} onRemove={() => removeToast(toast.id)} />
        ))}
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Heart className="w-6 h-6 text-white animate-heartbeat" />
              </div>
              <div>
                <h1 className="font-bold text-lg">MedUI Effects</h1>
                <p className="text-xs text-muted-foreground">Hospital System UI Kit</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              </Button>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent" />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-1 overflow-x-auto py-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-primary text-primary-foreground shadow-md'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <tab.icon className={`w-4 h-4 ${activeTab === tab.id ? 'animate-pulse' : ''}`} />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 transition-all duration-300 ${pageTransition ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
        
        {/* LOADING STATES TAB */}
        {activeTab === 'loading' && (
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h2 className="text-2xl font-bold mb-2">Loading States</h2>
              <p className="text-muted-foreground">Professional loading animations for healthcare systems</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Pulse Ring Loader */}
              <div className="p-8 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-6 text-center">Pulse Ring Loader</p>
                <div className="h-32 flex items-center justify-center">
                  <PulseRingLoader />
                </div>
                <p className="text-xs text-muted-foreground text-center mt-4">Best for: Page loads, system initialization</p>
              </div>

              {/* EKG Loader */}
              <div className="p-8 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-6 text-center">EKG Line Animation</p>
                <div className="h-32 flex items-center justify-center">
                  <EKGLoader />
                </div>
                <p className="text-xs text-muted-foreground text-center mt-4">Best for: Vitals monitoring, real-time data</p>
              </div>

              {/* DNA Loader */}
              <div className="p-8 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-6 text-center">DNA Helix Loader</p>
                <div className="h-32 flex items-center justify-center">
                  <DNALoader />
                </div>
                <p className="text-xs text-muted-foreground text-center mt-4">Best for: Lab results, genetic data</p>
              </div>
            </div>

            {/* Skeleton Loading */}
            <div className="p-8 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-6">Skeleton Loading States</p>
              <div className="grid md:grid-cols-3 gap-4">
                <SkeletonCard />
                <SkeletonCard />
                <SkeletonCard />
              </div>
            </div>

            {/* Progress Indicators */}
            <div className="p-8 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-6">Progress Indicators</p>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Uploading patient records...</span>
                    <span className="text-primary font-medium">65%</span>
                  </div>
                  <Progress value={65} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Processing lab results...</span>
                    <span className="text-accent font-medium">42%</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full w-[42%] bg-gradient-to-r from-primary to-accent rounded-full animate-pulse" />
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/50">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  <span className="text-sm">Syncing with EHR system...</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* COLOR SCHEMES TAB */}
        {activeTab === 'colors' && (
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h2 className="text-2xl font-bold mb-2">Healthcare Color Palette</h2>
              <p className="text-muted-foreground">Professional colors designed for medical interfaces</p>
            </div>

            <ColorPalette />

            {/* Color Usage Examples */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Status Indicators</p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-sm font-medium text-emerald-800">Stable - Patient vitals normal</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <div className="w-3 h-3 rounded-full bg-amber-500 animate-pulse" />
                    <span className="text-sm font-medium text-amber-800">Watch - Monitor closely</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg urgent-alert rounded-lg border border-red-300">
                    <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                    <span className="text-sm font-medium text-red-800">Critical - Immediate attention</span>
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Department Colors</p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
                      <Stethoscope className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">General Medicine</p>
                      <p className="text-xs text-muted-foreground">Medical Blue</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-rose-400 flex items-center justify-center">
                      <Heart className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Cardiology</p>
                      <p className="text-xs text-muted-foreground">Warm Coral</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-violet-500 flex items-center justify-center">
                      <Pill className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Pharmacy</p>
                      <p className="text-xs text-muted-foreground">Calm Purple</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-teal-500 flex items-center justify-center">
                      <Droplets className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Laboratory</p>
                      <p className="text-xs text-muted-foreground">Healing Teal</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PAGE TRANSITIONS TAB */}
        {activeTab === 'transitions' && (
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h2 className="text-2xl font-bold mb-2">Page Transitions</h2>
              <p className="text-muted-foreground">Smooth transitions for better user experience</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Fade In Up</p>
                <div className="h-40 flex items-center justify-center bg-muted/50 rounded-xl overflow-hidden">
                  <div className="animate-fade-in-up p-4 rounded-lg bg-primary text-white">
                    Content fades in from below
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Fade In Scale</p>
                <div className="h-40 flex items-center justify-center bg-muted/50 rounded-xl overflow-hidden">
                  <div className="animate-fade-in-scale p-4 rounded-lg bg-accent text-accent-foreground">
                    Content scales in smoothly
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Slide In Right</p>
                <div className="h-40 flex items-center justify-center bg-muted/50 rounded-xl overflow-hidden">
                  <div className="animate-slide-in-right p-4 rounded-lg bg-gradient-to-r from-primary to-accent text-white">
                    Content slides from right
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl border bg-card">
                <p className="text-sm font-semibold mb-4">Stagger Children</p>
                <div className="h-40 flex items-center justify-center bg-muted/50 rounded-xl overflow-hidden">
                  <div className="stagger-children flex gap-2">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="w-8 h-8 rounded-lg bg-primary" />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Demo */}
            <div className="p-6 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-4">Modal Animation</p>
              <Button onClick={() => setModalOpen(true)}>Open Modal</Button>
              
              <Dialog open={modalOpen} onOpenChange={setModalOpen}>
                <DialogContent className="animate-modal-in">
                  <DialogHeader>
                    <DialogTitle>Patient Details</DialogTitle>
                    <DialogDescription>
                      View and manage patient information
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-xl font-bold">
                        SJ
                      </div>
                      <div>
                        <p className="font-semibold">Sarah Johnson</p>
                        <p className="text-sm text-muted-foreground">Patient ID: PT-001</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 rounded-lg bg-muted">
                        <p className="text-xs text-muted-foreground">Age</p>
                        <p className="font-medium">45 years</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted">
                        <p className="text-xs text-muted-foreground">Blood Type</p>
                        <p className="font-medium">O+</p>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        )}

        {/* UI COMPONENTS TAB */}
        {activeTab === 'components' && (
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h2 className="text-2xl font-bold mb-2">UI Components</h2>
              <p className="text-muted-foreground">Pre-built components for hospital systems</p>
            </div>

            {/* Patient Cards */}
            <div>
              <p className="text-sm font-semibold mb-4">Patient Cards with Vitals</p>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {patients.map((patient, i) => (
                  <PatientCard key={i} patient={patient} index={i} />
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="p-6 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-4">Action Buttons</p>
              <div className="flex flex-wrap gap-3">
                <Button className="btn-ripple bg-gradient-to-r from-primary to-accent">
                  <Plus className="w-4 h-4 mr-2" />
                  New Patient
                </Button>
                <Button variant="outline" className="hover-border-glow">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule
                </Button>
                <Button variant="secondary" className="hover-lift">
                  <FileText className="w-4 h-4 mr-2" />
                  Records
                </Button>
                <Button 
                  variant="destructive"
                  onClick={() => addToast('error', 'Emergency Alert', 'Critical patient requires immediate attention')}
                >
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Emergency
                </Button>
              </div>
            </div>

            {/* Notification Triggers */}
            <div className="p-6 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-4">Toast Notifications</p>
              <div className="flex flex-wrap gap-3">
                <Button 
                  variant="outline"
                  onClick={() => addToast('success', 'Appointment Booked', 'Patient scheduled for tomorrow at 10:00 AM')}
                  className="border-emerald-500 text-emerald-600 hover:bg-emerald-50"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Success Toast
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => addToast('warning', 'Low Inventory', 'Medicine stock below minimum threshold')}
                  className="border-amber-500 text-amber-600 hover:bg-amber-50"
                >
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Warning Toast
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => addToast('info', 'System Update', 'New features available in dashboard')}
                  className="border-blue-500 text-blue-600 hover:bg-blue-50"
                >
                  <Activity className="w-4 h-4 mr-2" />
                  Info Toast
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* HOVER EFFECTS TAB */}
        {activeTab === 'effects' && (
          <div className="space-y-8 animate-fade-in-up">
            <div>
              <h2 className="text-2xl font-bold mb-2">Hover Effects</h2>
              <p className="text-muted-foreground">Interactive hover states for better engagement</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Lift Effect */}
              <div className="p-6 rounded-2xl border bg-card hover-lift cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <p className="font-semibold mb-2">Lift Effect</p>
                <p className="text-sm text-muted-foreground">Card lifts up with shadow on hover</p>
              </div>

              {/* Glow Effect */}
              <div className="p-6 rounded-2xl border bg-card hover-glow cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                  <Sparkles className="w-6 h-6 text-accent" />
                </div>
                <p className="font-semibold mb-2">Glow Effect</p>
                <p className="text-sm text-muted-foreground">Subtle glow appears on hover</p>
              </div>

              {/* Scale Effect */}
              <div className="p-6 rounded-2xl border bg-card hover-scale cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-violet-500" />
                </div>
                <p className="font-semibold mb-2">Scale Effect</p>
                <p className="text-sm text-muted-foreground">Element scales up on hover</p>
              </div>
            </div>

            {/* Glass Card Effect */}
            <div className="p-8 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20">
              <p className="text-sm font-semibold mb-4">Glass Morphism Card</p>
              <div className="glass-card p-6 rounded-xl">
                <div className="flex items-center gap-4">
                  <Shield className="w-10 h-10 text-primary" />
                  <div>
                    <p className="font-semibold">HIPAA Compliant</p>
                    <p className="text-sm text-muted-foreground">Your data is secure with end-to-end encryption</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Gradient Border Cards */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="gradient-border-card p-6">
                <p className="font-semibold mb-2">Gradient Border</p>
                <p className="text-sm text-muted-foreground">Subtle gradient border that adds depth to cards</p>
              </div>
              <div className="gradient-border-card p-6">
                <p className="font-semibold mb-2">Premium Feel</p>
                <p className="text-sm text-muted-foreground">Perfect for highlighting important information</p>
              </div>
            </div>

            {/* Interactive Stats */}
            <div className="p-6 rounded-2xl border bg-card">
              <p className="text-sm font-semibold mb-4">Interactive Stats</p>
              <div className="grid grid-cols-4 gap-4">
                {[
                  { label: 'Patients', value: '1,247', icon: Users, color: 'text-blue-500' },
                  { label: 'Doctors', value: '48', icon: Stethoscope, color: 'text-emerald-500' },
                  { label: 'Appointments', value: '89', icon: Calendar, color: 'text-violet-500' },
                  { label: 'Revenue', value: '$48K', icon: CreditCard, color: 'text-amber-500' },
                ].map((stat, i) => (
                  <div 
                    key={i} 
                    className="p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors cursor-pointer group"
                  >
                    <stat.icon className={`w-6 h-6 ${stat.color} mb-2 group-hover:scale-110 transition-transform`} />
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

// Missing import
function Layout({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <rect width="7" height="9" x="3" y="3" rx="1" />
      <rect width="7" height="5" x="14" y="3" rx="1" />
      <rect width="7" height="9" x="14" y="12" rx="1" />
      <rect width="7" height="5" x="3" y="16" rx="1" />
    </svg>
  );
}

export default App;
